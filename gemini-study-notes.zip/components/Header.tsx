import React from 'react';
import { useAuth } from '../context/AuthContext';
import { LogoutIcon } from './icons/LogoutIcon';

export const Header: React.FC = () => {
  const { currentUser, logout } = useAuth();

  return (
    <header className="flex items-center justify-between p-2 bg-gray-900 border-b border-gray-700">
      <div className="text-sm text-gray-400">
        Logged in as: <span className="font-semibold text-gray-200">{currentUser?.email}</span>
      </div>
      <button 
        onClick={logout}
        className="flex items-center gap-2 px-3 py-2 rounded-md bg-gray-700 hover:bg-red-600 text-sm font-medium transition-colors"
        aria-label="Log out"
      >
        <LogoutIcon className="w-4 h-4" />
        <span>Logout</span>
      </button>
    </header>
  );
};
