import React, { useState } from 'react';

interface TagInputProps {
  tags: string[];
  onTagsChange: (tags: string[]) => void;
}

export const TagInput: React.FC<TagInputProps> = ({ tags, onTagsChange }) => {
  const [inputValue, setInputValue] = useState('');

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const newTag = inputValue.trim();
      if (newTag && !tags.includes(newTag)) {
        onTagsChange([...tags, newTag]);
      }
      setInputValue('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    onTagsChange(tags.filter(tag => tag !== tagToRemove));
  };

  return (
    <div className="mt-4 border-t border-gray-700 pt-2">
        <div className="flex flex-wrap gap-2 items-center">
        {tags.map(tag => (
            <div key={tag} className="flex items-center bg-indigo-600 text-white text-xs font-semibold px-2 py-1 rounded-full">
            <span>{tag}</span>
            <button onClick={() => removeTag(tag)} className="ml-2 text-indigo-200 hover:text-white">
                &#x2715;
            </button>
            </div>
        ))}
        <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Add tags..."
            className="bg-transparent focus:outline-none text-sm p-1 flex-grow"
        />
        </div>
    </div>
  );
};
