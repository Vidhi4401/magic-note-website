import React from 'react';
import { SaveIcon } from './icons/SaveIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { SparklesIcon } from './icons/SparklesIcon';

interface ToolbarProps {
  onSave: () => void;
  onDownload: () => void;
  onEnhance: () => void;
  isAiLoading: boolean;
  hasUnsavedChanges: boolean;
}

const ToolbarButton: React.FC<{onClick: () => void; disabled?: boolean; children: React.ReactNode; label: string; className?: string}> = ({ onClick, disabled, children, label, className = '' }) => (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center gap-2 px-3 py-2 rounded-md bg-gray-700 hover:bg-indigo-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-sm font-medium transition-all duration-200 ${className}`}
      aria-label={label}
    >
      {children}
    </button>
);


export const Toolbar: React.FC<ToolbarProps> = ({ onSave, onDownload, onEnhance, isAiLoading, hasUnsavedChanges }) => {
  return (
    <div className="flex items-center justify-end p-2 bg-gray-900 border-b border-gray-700 space-x-2">
      <ToolbarButton onClick={onSave} label="Save note" className={hasUnsavedChanges ? 'bg-green-600 hover:bg-green-500' : ''}>
        <SaveIcon className="w-4 h-4" />
        <span>{hasUnsavedChanges ? 'Save*' : 'Saved'}</span>
      </ToolbarButton>
      <ToolbarButton onClick={onDownload} label="Download note">
        <DownloadIcon className="w-4 h-4" />
        <span>Download</span>
      </ToolbarButton>
      <ToolbarButton onClick={onEnhance} disabled={isAiLoading} label="Auto-correct & Enhance with Gemini">
        {isAiLoading ? (
            <div className="w-4 h-4 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
        ) : (
            <SparklesIcon className="w-4 h-4" />
        )}
        <span>{isAiLoading ? 'Enhancing...' : 'Enhance'}</span>
      </ToolbarButton>
    </div>
  );
};