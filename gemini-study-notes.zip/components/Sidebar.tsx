import React, { useState } from 'react';
import type { Note, Folder } from '../types';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';
import { FolderIcon } from './icons/FolderIcon';

interface SidebarProps {
  notes: Note[];
  folders: Folder[];
  activeNoteId: string | null;
  activeFolderId: string | null;
  onSelectNote: (id: string) => void;
  onNewNote: () => void;
  onDeleteNote: (id: string) => void;
  onNewFolder: (name: string) => void;
  onSelectFolder: (id: string | null) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ notes, folders, activeNoteId, activeFolderId, onSelectNote, onNewNote, onDeleteNote, onNewFolder, onSelectFolder }) => {
  const [newFolderName, setNewFolderName] = useState('');
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);

  const handleCreateFolder = () => {
    if (newFolderName.trim()) {
      onNewFolder(newFolderName.trim());
      setNewFolderName('');
      setIsCreatingFolder(false);
    }
  };

  const filteredNotes = activeFolderId ? notes.filter(note => note.folderId === activeFolderId) : notes;
  const sortedFolders = [...folders].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <aside className="w-80 bg-gray-900 border-r border-gray-700 flex flex-col p-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold text-white">My Notes</h1>
        <button 
          onClick={onNewNote}
          className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors duration-200"
          aria-label="Create new note"
        >
          <PlusIcon className="w-5 h-5" />
        </button>
      </div>

      {/* Folders Section */}
      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
            <h2 className="text-sm font-semibold text-gray-400 uppercase">Folders</h2>
            <button onClick={() => setIsCreatingFolder(!isCreatingFolder)} className="p-1 text-gray-400 hover:text-white"><PlusIcon className="w-4 h-4" /></button>
        </div>
        {isCreatingFolder && (
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              placeholder="New folder name"
              className="w-full bg-gray-700 text-white text-sm rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              onKeyDown={(e) => e.key === 'Enter' && handleCreateFolder()}
            />
            <button onClick={handleCreateFolder} className="bg-indigo-600 text-white px-2 py-1 rounded text-sm hover:bg-indigo-500">Add</button>
          </div>
        )}
        <div className="space-y-1">
            <div onClick={() => onSelectFolder(null)} className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors ${!activeFolderId ? 'bg-indigo-600' : 'hover:bg-gray-700'}`}>
                <FolderIcon className="w-5 h-5" />
                <span className="text-sm font-medium">All Notes</span>
            </div>
            {sortedFolders.map(folder => (
                <div key={folder.id} onClick={() => onSelectFolder(folder.id)} className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors ${activeFolderId === folder.id ? 'bg-indigo-600' : 'hover:bg-gray-700'}`}>
                    <FolderIcon className="w-5 h-5" />
                    <span className="text-sm font-medium truncate">{folder.name}</span>
                </div>
            ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-2 pr-2 border-t border-gray-700 pt-4">
        {filteredNotes.map(note => (
          <div key={note.id} className="group relative">
             <div
              onClick={() => onSelectNote(note.id)}
              className={`
                p-3 rounded-lg cursor-pointer transition-all duration-200 ease-in-out
                ${activeNoteId === note.id ? 'bg-indigo-600 shadow-lg' : 'bg-gray-800 hover:bg-gray-700'}
              `}
            >
              <h3 className="font-semibold truncate text-sm">{note.title || 'Untitled Note'}</h3>
              <p className="text-xs text-gray-400 mt-1">
                {new Date(note.updatedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </p>
            </div>
            <button 
              onClick={(e) => { e.stopPropagation(); onDeleteNote(note.id); }}
              className="absolute top-2 right-2 text-gray-400 hover:text-red-500 transition-all duration-200 opacity-0 group-hover:opacity-100 p-1 rounded-full bg-gray-800 hover:bg-gray-600"
              aria-label="Delete note"
            >
              <TrashIcon className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </aside>
  );
};