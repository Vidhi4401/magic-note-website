import React, { useState, useEffect, useCallback } from 'react';
import { Toolbar } from './Toolbar';
import { TagInput } from './TagInput';
import type { Note } from '../types';

interface EditorProps {
  note: Note;
  onNoteUpdate: (updatedNote: Partial<Note>) => void;
  onDownload: () => void;
  onEnhance: (content: string) => Promise<string>;
  isAiLoading: boolean;
}

export const Editor: React.FC<EditorProps> = ({ note, onNoteUpdate, onDownload, onEnhance, isAiLoading }) => {
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [tags, setTags] = useState<string[]>(note.tags);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  useEffect(() => {
    setTitle(note.title);
    setContent(note.content);
    setTags(note.tags);
    setHasUnsavedChanges(false);
  }, [note]);

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
    setHasUnsavedChanges(true);
  };
  
  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setHasUnsavedChanges(true);
  };
  
  const handleTagsChange = (newTags: string[]) => {
    setTags(newTags);
    setHasUnsavedChanges(true);
  }

  const handleSave = useCallback(() => {
    onNoteUpdate({ id: note.id, title, content, tags });
    setHasUnsavedChanges(false);
  }, [note.id, title, content, tags, onNoteUpdate]);

  const handleEnhance = async () => {
    const enhancedContent = await onEnhance(content);
    setContent(enhancedContent);
    onNoteUpdate({ id: note.id, title, content: enhancedContent, tags });
    setHasUnsavedChanges(false);
  };

  return (
    <div className="flex-1 flex flex-col bg-gray-800">
      <Toolbar 
        onSave={handleSave}
        onDownload={onDownload}
        onEnhance={handleEnhance}
        isAiLoading={isAiLoading}
        hasUnsavedChanges={hasUnsavedChanges}
      />
      <div className="p-6 flex-grow flex flex-col">
        <input 
          type="text"
          value={title}
          onChange={handleTitleChange}
          placeholder="Note Title"
          className="w-full bg-transparent text-2xl font-bold mb-4 focus:outline-none text-white placeholder-gray-500"
        />
        <textarea
          value={content}
          onChange={handleContentChange}
          placeholder="Start writing your brilliant notes here..."
          className="w-full h-full bg-transparent text-gray-200 resize-none focus:outline-none text-base leading-relaxed flex-grow"
        />
        <TagInput tags={tags} onTagsChange={handleTagsChange} />
      </div>
    </div>
  );
};