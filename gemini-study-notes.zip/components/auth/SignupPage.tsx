import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';

const SignupPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { signup } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(password.length < 6) {
        setError("Password must be at least 6 characters long.");
        return;
    }
    setError('');
    // NOTE: In a real application, NEVER store passwords in plaintext.
    // This is a simplified example for demonstration purposes.
    const success = signup(email, password);
    if (!success) {
      setError('An account with this email already exists.');
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-center text-white">Sign Up</h2>
      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        <div>
          <label htmlFor="email-signup" className="block text-sm font-medium text-gray-300">Email</label>
          <input
            id="email-signup"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div>
          <label htmlFor="password-signup" className="block text-sm font-medium text-gray-300">Password</label>
          <input
            id="password-signup"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full px-3 py-2 mt-1 text-white bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button type="submit" className="w-full px-4 py-2 font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500">
          Sign Up
        </button>
      </form>
    </div>
  );
};

export default SignupPage;
