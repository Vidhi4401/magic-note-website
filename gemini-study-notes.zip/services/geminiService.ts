import { GoogleGenAI } from "@google/genai";

// Fix: Per coding guidelines, initialize with API_KEY from environment variables directly.
// Assume process.env.API_KEY is pre-configured and valid, removing redundant checks and variables.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const enhanceNoteWithGemini = async (text: string): Promise<string> => {
  // Fix: Per coding guidelines, we assume API key is always available. Removed redundant check.
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Please proofread and correct the spelling and grammar of the following study note. Improve clarity and flow where possible, but strictly preserve the original meaning, tone, and formatting (like bullet points or headings). Return only the corrected text, without any additional commentary, intro, or outro.

Here is the text:
---
${text}
---`,
    });
    
    return response.text.trim();
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to enhance note with Gemini.");
  }
};
