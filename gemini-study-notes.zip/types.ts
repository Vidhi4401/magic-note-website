export interface User {
  id: string;
  email: string;
  passwordHash: string; // In a real app, this would be a secure hash.
}

export interface Folder {
  id: string;
  name: string;
  userId: string;
  createdAt: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  userId: string;
  folderId: string | null;
  tags: string[];
}