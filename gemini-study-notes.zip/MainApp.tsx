import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Editor } from './components/Editor';
import { Header } from './components/Header';
import type { Note, Folder } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import { enhanceNoteWithGemini } from './services/geminiService';
import { useAuth } from './context/AuthContext';

const MainApp: React.FC = () => {
  const { currentUser } = useAuth();
  const [notes, setNotes] = useLocalStorage<Note[]>(`notes-${currentUser!.id}`, []);
  const [folders, setFolders] = useLocalStorage<Folder[]>(`folders-${currentUser!.id}`, []);
  
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const activeNote = notes.find(note => note.id === activeNoteId);
  
  const filteredNotes = activeFolderId
    ? notes.filter(note => note.folderId === activeFolderId)
    : notes;

  useEffect(() => {
    const notesToConsider = filteredNotes.length > 0 ? filteredNotes : notes;
    if (notesToConsider.length > 0 && (!activeNoteId || !notesToConsider.some(n => n.id === activeNoteId))) {
      setActiveNoteId(notesToConsider[0].id);
    } else if (notesToConsider.length === 0) {
      setActiveNoteId(null);
    }
  }, [notes, activeFolderId, filteredNotes, activeNoteId]);

  const handleSelectNote = (id: string) => {
    setActiveNoteId(id);
  };

  const handleNoteUpdate = useCallback((updatedNote: Partial<Note>) => {
    if (!updatedNote.id) return;
    const now = new Date().toISOString();
    setNotes(prevNotes => 
      prevNotes.map(note => 
        note.id === updatedNote.id ? { ...note, ...updatedNote, updatedAt: now } : note
      )
    );
  }, [setNotes]);

  const handleNewNote = () => {
    if (!currentUser) return;
    const newNote: Note = {
      id: crypto.randomUUID(),
      title: 'Untitled Note',
      content: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      userId: currentUser.id,
      folderId: activeFolderId,
      tags: [],
    };
    setNotes(prevNotes => [newNote, ...prevNotes]);
    setActiveNoteId(newNote.id);
  };
  
  const handleNewFolder = (name: string) => {
    if (!currentUser) return;
    const newFolder: Folder = {
      id: crypto.randomUUID(),
      name,
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
    };
    setFolders(prevFolders => [newFolder, ...prevFolders]);
    setActiveFolderId(newFolder.id);
  };

  const handleDeleteNote = (id: string) => {
    setNotes(prevNotes => prevNotes.filter(note => note.id !== id));
    if (activeNoteId === id) {
      setActiveNoteId(null); 
    }
  };

  const handleDownloadNote = () => {
    if (!activeNote) return;
    const blob = new Blob([activeNote.content], { type: 'text/markdown;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    const title = activeNote.title.replace(/ /g, '_');
    link.download = `${title}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleEnhanceNote = async (content: string): Promise<string> => {
    if (!content) return content;
    setIsAiLoading(true);
    setError(null);
    try {
      const enhancedContent = await enhanceNoteWithGemini(content);
      return enhancedContent;
    } catch (err) {
      setError('Failed to enhance note. Please try again.');
      console.error(err);
      return content; // Return original content on failure
    } finally {
      setIsAiLoading(false);
    }
  };

  const sortedNotes = [...filteredNotes].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  return (
    <div className="flex h-screen flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar 
          notes={sortedNotes}
          folders={folders}
          activeNoteId={activeNoteId}
          activeFolderId={activeFolderId}
          onSelectNote={handleSelectNote}
          onNewNote={handleNewNote}
          onDeleteNote={handleDeleteNote}
          onNewFolder={handleNewFolder}
          onSelectFolder={setActiveFolderId}
        />
        <main className="flex-1 flex flex-col">
          {activeNote ? (
            <Editor 
              key={activeNote.id}
              note={activeNote}
              onNoteUpdate={handleNoteUpdate}
              onDownload={handleDownloadNote}
              onEnhance={handleEnhanceNote}
              isAiLoading={isAiLoading}
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
              <h2 className="text-2xl font-semibold">Welcome to Gemini Study Notes</h2>
              <p className="mt-2">Select a folder and create a new note to get started.</p>
            </div>
          )}
          {error && (
              <div className="absolute bottom-4 right-4 bg-red-500 text-white p-3 rounded-lg shadow-lg animate-pulse">
                  {error}
              </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default MainApp;
