import React from 'react';
import { useAuth } from './context/AuthContext';
import AuthPage from './components/auth/AuthPage';
import MainApp from './MainApp';

const App: React.FC = () => {
  const { currentUser } = useAuth();
  
  return (
    <div className="h-screen bg-gray-900 text-white font-sans">
      {currentUser ? <MainApp /> : <AuthPage />}
    </div>
  );
};

export default App;